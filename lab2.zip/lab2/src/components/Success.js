import React from 'react'

function Success(props) {

    console.log(props)
  return (
    <div >

    <h3>Name : {props.data[0].name}</h3>
    <h3>Email : {props.data[0].email}</h3>
    <h3>Address : {props.data[0].address}</h3>
    <h3>Phone : {props.data[0].phone}</h3>
    <h3>Department : {props.data[0].dept}</h3>
    <h3>SEM : {props.data[0].sem}</h3>
    <h3>Fees : {props.data[0].fees}</h3>
    <h3>CGPA : {props.data[0].cgpa}</h3>

    </div>
  )
}

export default Success