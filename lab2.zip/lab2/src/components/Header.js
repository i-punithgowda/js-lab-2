import React from 'react'

function Header() {
  return (
    <div>
        <h2>Welcome to Student registration</h2>
    </div>
  )
}

export default Header